import { motion } from "motion/react";
import { Key, HardDrive, Laptop, Gamepad2, Cpu, Monitor, ArrowRight, type LucideIcon } from "lucide-react";

export function ProductsSection() {
  return (
    <section id="productos" className="py-24 container mx-auto px-6">
      <div className="mb-16">
        <h2 className="text-4xl font-bold text-white uppercase tracking-tight">
          Productos y Licencias Originales
        </h2>
        <div className="mt-4 w-24 h-1 bg-primary rounded-full" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Column 1: Software Licenses */}
        <div className="space-y-6">
          <div className="flex items-center gap-3 mb-8">
            <Key className="w-6 h-6 text-primary" />
            <h3 className="text-2xl font-bold text-white">Licencias de Software</h3>
          </div>
          
          <LicenseCard 
            title="Windows 10/11 Pro"
            subtitle="Licencia Digital Permanente OEM/Retail"
            icon="🪟"
          />
          <LicenseCard 
            title="Microsoft Office 365 / 2021"
            subtitle="Cuentas institucionales y licencias de por vida"
            icon="📊"
          />
        </div>

        {/* Column 2: Hardware & Equipment */}
        <div className="space-y-6">
          <div className="flex items-center gap-3 mb-8">
            <HardDrive className="w-6 h-6 text-primary" />
            <h3 className="text-2xl font-bold text-white">Hardware & Equipos</h3>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <HardwareCard title="Laptops" icon={Laptop} />
            <HardwareCard title="PCs Gamer" icon={Gamepad2} />
            <HardwareCard title="SSD / RAM" icon={Cpu} />
            <HardwareCard title="Monitores" icon={Monitor} />
          </div>
        </div>
      </div>
    </section>
  );
}

function LicenseCard({ title, subtitle, icon }: { title: string, subtitle: string, icon: string }) {
  return (
    <div className="glass glass-hover p-6 rounded-2xl flex items-center justify-between group cursor-pointer">
      <div className="flex items-center gap-6">
        <div className="text-3xl p-4 bg-white/5 rounded-xl">{icon}</div>
        <div>
          <h4 className="text-lg font-bold text-white group-hover:text-primary transition-colors">{title}</h4>
          <p className="text-sm text-on-surface/50">{subtitle}</p>
        </div>
      </div>
      <ArrowRight className="w-5 h-5 text-on-surface/30 group-hover:text-primary transition-all group-hover:translate-x-1" />
    </div>
  );
}

function HardwareCard({ title, icon: Icon }: { title: string, icon: LucideIcon }) {
  return (
    <div className="glass glass-hover p-8 rounded-2xl flex flex-col items-center gap-4 text-center group cursor-pointer">
      <Icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform" />
      <span className="font-bold text-white group-hover:text-primary transition-colors uppercase text-sm tracking-wider">{title}</span>
    </div>
  );
}
