import { motion } from "motion/react";
import { Download } from "lucide-react";

const REMOTE_TOOLS = [
  { name: "AnyDesk", icon: "🌐" },
  { name: "TeamViewer", icon: "⚽" },
  { name: "RustDesk", icon: "🦀" },
];

export function RemoteSupport() {
  return (
    <section className="py-24 bg-surface-container/20">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl font-bold text-white mb-4 uppercase">
          Soporte Técnico Remoto
        </h2>
        <p className="text-on-surface/60 max-w-2xl mx-auto mb-12">
          Descarga las herramientas oficiales para que podamos conectarnos a tu equipo y solucionar cualquier problema técnico al instante.
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 max-w-5xl mx-auto">
          {REMOTE_TOOLS.map((tool, idx) => (
            <motion.div
              key={tool.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass p-8 md:p-10 rounded-2xl group hover:border-primary/50 transition-all flex flex-col items-center"
            >
              <div className="text-4xl md:text-5xl mb-4 md:mb-6">{tool.icon}</div>
              <h3 className="text-lg md:text-xl font-bold text-white mb-4 md:mb-6 group-hover:text-primary transition-colors">
                {tool.name}
              </h3>
              <button className="flex items-center gap-2 text-primary font-bold uppercase text-xs md:text-sm hover:underline">
                Descargar
                <Download className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
