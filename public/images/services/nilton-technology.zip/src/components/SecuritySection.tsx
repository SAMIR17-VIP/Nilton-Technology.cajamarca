import { motion } from "motion/react";
import { Shield, Lock } from "lucide-react";

const ANTIVIRUS_LIST = [
  { name: "ESET NOD32", img: "/images/antivirus/eset.png" },
  { name: "Kaspersky", img: "/images/antivirus/kaspersky.png" },
  { name: "Avast Premium", img: "/images/antivirus/avast.png" },
];

export function SecuritySection() {
  return (
    <section id="seguridad" className="py-24 container mx-auto px-6">
      <div className="glass p-12 rounded-[2rem] flex flex-col md:flex-row items-center gap-12 overflow-hidden relative">
        {/* Abstract background glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2" />
        
        <div className="flex-1 space-y-6 relative z-10">
          <div className="inline-flex p-3 rounded-xl bg-primary/10 text-primary mb-4 border border-primary/20">
            <Shield className="w-8 h-8" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white uppercase tracking-tight">
            Seguridad Total
          </h2>
          <p className="text-xl text-on-surface/70 leading-relaxed max-w-xl">
            Protegemos tu equipo contra virus, malware y ataques cibernéticos con los mejores motores de búsqueda y protección en tiempo real.
          </p>
          
          <div className="flex flex-wrap gap-4 pt-4">
            {ANTIVIRUS_LIST.map((antivirus) => (
              <div 
                key={antivirus.name}
                className="flex items-center gap-3 px-4 py-2 rounded-lg bg-white/5 border border-white/10 text-sm font-medium text-white/80 group hover:bg-white/10 transition-colors"
              >
                <div className="w-6 h-6 flex items-center justify-center relative bg-white/10 rounded p-1">
                  <img 
                    src={antivirus.img} 
                    alt={antivirus.name}
                    className="w-full h-full object-contain"
                    onError={(e) => {
                      const target = e.currentTarget;
                      target.style.display = 'none';
                      const fallback = target.nextElementSibling as HTMLElement;
                      if (fallback) fallback.classList.remove('hidden');
                    }}
                  />
                  <div className="w-2 h-2 rounded-full bg-primary hidden" />
                </div>
                {antivirus.name}
              </div>
            ))}
          </div>
        </div>

        <div className="flex-1 flex justify-center items-center relative py-10 md:py-0">
           <motion.div
             initial={{ scale: 0.8, opacity: 0 }}
             whileInView={{ scale: 1, opacity: 1 }}
             viewport={{ once: true }}
             className="relative"
           >
              <div className="absolute inset-0 bg-primary/30 blur-[60px] rounded-full scale-150" />
              <Lock className="w-48 h-48 md:w-64 md:h-64 text-primary relative z-10 drop-shadow-[0_0_30px_rgba(37,99,235,0.5)]" />
           </motion.div>
        </div>
      </div>
    </section>
  );
}
