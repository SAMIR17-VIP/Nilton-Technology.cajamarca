import { motion } from "motion/react";
import { MessageSquare, LayoutGrid } from "lucide-react";

export function Hero() {
  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="/images/hero-bg.jpg" 
          alt="Technical Remote Support Background"
          className="w-full h-full object-cover opacity-20 md:opacity-40"
          onError={(e) => {
            const target = e.currentTarget;
            if (target.src.includes('hero-bg.jpg')) {
              target.src = "/images/publicimageshero-bg.jpg";
            } else {
              target.src = "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80";
            }
          }}
        />
        <div className="absolute inset-0 bg-linear-to-b from-background/40 via-background/80 to-background" />
      </div>

      <div className="container relative z-10 px-6 pt-24 md:pt-0 text-center md:text-left flex flex-col items-center md:items-start max-w-7xl mx-auto">
        <motion.div
           initial={{ opacity: 0, x: -20 }}
           animate={{ opacity: 1, x: 0 }}
           className="flex items-center gap-2 mb-4"
        >
          <div className="w-8 h-px bg-primary hidden md:block" />
          <span className="text-primary font-semibold tracking-widest text-[10px] md:text-xs uppercase">
            Instalación Remota vía AnyDesk • Laptop & PC
          </span>
        </motion.div>
        
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-7xl lg:text-8xl font-bold mb-6 text-white leading-[1.1] md:leading-[1.05]"
        >
          NILTON<span className="text-primary text-glow">TECHNOLOGY</span>
        </motion.h1>

        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 0.2 }}
           className="max-w-2xl"
        >
          <h2 className="text-lg md:text-2xl font-bold text-secondary mb-4 uppercase tracking-tighter">
            Especialista en Soporte Técnico de Alto Rendimiento
          </h2>
          <p className="text-on-surface/70 text-base md:text-lg mb-10 leading-relaxed">
            Realizamos instalaciones profesionales y seguras directamente en tu equipo. Sin importar dónde estés, optimizamos tu laptop o PC para ingeniería, diseño y productividad.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
        >
          <a href="https://wa.me/51901120575" className="btn-primary w-full sm:w-auto">
            <MessageSquare className="w-5 h-5" />
            Soporte Remoto Ahora
          </a>
          <button className="btn-secondary w-full sm:w-auto">
            <LayoutGrid className="w-5 h-5" />
            Catálogo Programas
          </button>
        </motion.div>
      </div>

      {/* Subtle floating accent */}
      <div className="absolute bottom-10 right-10 hidden lg:block opacity-20">
         <div className="glass p-4 rounded-xl flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-primary/20 animate-pulse flex items-center justify-center">
               <div className="w-4 h-4 rounded-full bg-primary" />
            </div>
            <div className="text-xs font-mono uppercase tracking-[0.2em] text-white">
               Service Status: ONLINE
            </div>
         </div>
      </div>
    </section>
  );
}
