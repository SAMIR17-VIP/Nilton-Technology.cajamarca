import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import { LucideIcon } from "lucide-react";

interface SoftwareCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  img?: string;
  index: number;
  key?: string;
}

export function SoftwareCard({ title, description, icon: Icon, img, index }: SoftwareCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.05 }}
      className="glass glass-hover p-6 rounded-xl flex flex-col gap-4 group"
    >
      <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center transition-colors group-hover:bg-primary/10 relative overflow-hidden p-2">
        {img && (
          <img 
            src={img} 
            alt={title}
            className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-110"
            onError={(e) => {
              const target = e.currentTarget;
              target.style.display = 'none';
              const fallback = target.nextElementSibling as HTMLElement;
              if (fallback) fallback.classList.remove('hidden');
            }}
          />
        )}
        <Icon className={cn("w-6 h-6 text-primary", img ? "hidden" : "")} />
      </div>
      <div>
        <h3 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
          {title}
        </h3>
        <p className="text-sm text-on-surface/60 leading-relaxed">
          {description}
        </p>
      </div>
    </motion.div>
  );
}

import { 
  Monitor, 
  Settings, 
  ShieldCheck, 
  Cpu, 
  PenTool, 
  Layers, 
  Wrench,
  Key
} from "lucide-react";

const SOFTWARE_SERVICES = [
  {
    title: "Microsoft Office",
    description: "Versiones 2019, 2021, LTSC y Microsoft 365 con activación permanente.",
    icon: Monitor,
    img: "/images/services/office.png"
  },
  {
    title: "Windows OS",
    description: "Instalación y optimización de Windows 10 y 11 Pro/Home.",
    icon: Settings,
    img: "/images/services/windows.png"
  },
  {
    title: "Drivers & Drivers Pack",
    description: "Actualización de controladores para máximo rendimiento del hardware.",
    icon: Cpu,
    img: "/images/services/drivers.png"
  },
  {
    title: "Activaciones",
    description: "Activación de software y sistemas operativos mediante licencia digital.",
    icon: Key,
    img: "/images/services/activations.png"
  },
  {
    title: "Optimización",
    description: "Aceleración de inicio, limpieza de temporales y mejora de procesos.",
    icon: Wrench,
    img: "/images/services/optimization.png"
  },
  {
    title: "Software Ingeniería",
    description: "AutoCAD, Revit, Civil 3D y suites completas de cálculo estructural.",
    icon: Layers,
    img: "/images/services/engineering.png"
  },
  {
    title: "Software Diseño",
    description: "Adobe Creative Cloud, CorelDRAW y herramientas de edición profesional.",
    icon: PenTool,
    img: "/images/services/design.png"
  },
  {
    title: "Soporte Remoto",
    description: "Asistencia técnica inmediata vía AnyDesk para cualquier solución.",
    icon: ShieldCheck,
    img: "/images/services/remote.png"
  },
];

export function SoftwareGrid() {
  return (
    <section id="servicios" className="py-24 container mx-auto px-6">
      <div className="mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 uppercase tracking-tight">
          Instalación de Programas
        </h2>
        <div className="w-20 h-1 bg-primary rounded-full" />
      </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {SOFTWARE_SERVICES.map((service, idx) => (
            <SoftwareCard key={service.title} {...service} index={idx} />
          ))}
        </div>
    </section>
  );
}
