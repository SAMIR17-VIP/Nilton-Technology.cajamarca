import { motion } from "motion/react";
import { MessageSquare, Send, Instagram, Facebook, Globe } from "lucide-react";

export function ContactSection() {
  return (
    <section id="contacto" className="py-24 container mx-auto px-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
        {/* Contact Info */}
        <div className="space-y-8 md:space-y-12">
          <div>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-4 uppercase leading-tight">
              Contacto<br/><span className="text-primary text-glow">Oficial</span>
            </h2>
            <div className="w-16 md:w-24 h-1 bg-primary rounded-full" />
          </div>

          <div className="glass p-6 md:p-8 rounded-2xl flex flex-col sm:flex-row items-center gap-6 group hover:border-primary/40 transition-all text-center sm:text-left">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
              <MessageSquare className="w-8 h-8" />
            </div>
            <div>
              <p className="text-[10px] md:text-sm font-medium text-on-surface/50 uppercase tracking-widest mb-1">WhatsApp Oficial</p>
              <p className="text-xl md:text-2xl font-bold text-white group-hover:text-primary transition-colors">+51 901 120 575</p>
            </div>
          </div>

          <div className="flex gap-4 justify-center lg:justify-start">
             <SocialLink icon={Instagram} />
             <SocialLink icon={Facebook} />
             <SocialLink icon={Globe} />
          </div>
        </div>

        {/* Form */}
        <div className="glass p-6 md:p-10 rounded-2xl md:rounded-[2rem]">
          <form className="space-y-5 md:space-y-6">
            <div className="space-y-2">
              <label className="text-xs md:text-sm font-semibold text-white uppercase tracking-wider">Nombre Completo</label>
              <input 
                type="text" 
                placeholder="Ej. Juan Pérez"
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 md:px-5 py-3 md:py-4 text-sm md:text-base text-white focus:outline-hidden focus:border-primary transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs md:text-sm font-semibold text-white uppercase tracking-wider">Software que necesita</label>
              <input 
                type="text" 
                placeholder="Ej. AutoCAD 2024"
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 md:px-5 py-3 md:py-4 text-sm md:text-base text-white focus:outline-hidden focus:border-primary transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs md:text-sm font-semibold text-white uppercase tracking-wider">Mensaje o Detalles</label>
              <textarea 
                rows={4}
                placeholder="Describa su problema técnico o requerimiento..."
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 md:px-5 py-3 md:py-4 text-sm md:text-base text-white focus:outline-hidden focus:border-primary transition-colors resize-none"
              />
            </div>
            <button type="submit" className="btn-primary w-full py-4 md:py-5 text-sm md:text-lg uppercase tracking-widest font-bold">
              Enviar Solicitud
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function SocialLink({ icon: Icon }: { icon: any }) {
  return (
    <button className="w-14 h-14 rounded-xl glass flex items-center justify-center text-on-surface/70 hover:text-primary hover:border-primary/50 transition-all">
      <Icon className="w-6 h-6" />
    </button>
  );
}
