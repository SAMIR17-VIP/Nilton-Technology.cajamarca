export function Footer() {
  return (
    <footer className="py-12 border-t border-white/5 bg-black/40">
      <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-8">
        <div>
          <span className="text-xl font-bold tracking-tighter text-white">
            NILTON<span className="text-primary uppercase">Technology</span>
          </span>
          <p className="text-xs text-on-surface/40 mt-2">
            © 2024 NILTONTECHNOLOGY. High-Performance Engineering.
          </p>
        </div>

        <div className="flex gap-8 text-xs font-semibold text-on-surface/50 uppercase tracking-widest">
           <a href="#" className="hover:text-primary transition-colors">WhatsApp</a>
           <a href="#" className="hover:text-primary transition-colors">TikTok</a>
           <a href="#" className="hover:text-primary transition-colors">Instagram</a>
           <a href="#" className="hover:text-primary transition-colors">Facebook</a>
        </div>
      </div>
    </footer>
  );
}
