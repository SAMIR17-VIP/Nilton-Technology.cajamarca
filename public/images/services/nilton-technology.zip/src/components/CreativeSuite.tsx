import { motion } from "motion/react";

const CREATIVE_APPS = [
  {
    title: "Adobe Photoshop & Illustrator",
    description: "Edición fotográfica y diseño vectorial profesional con todas las funciones activas.",
    image: "/images/creative-1.jpg",
    fallback: "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&q=80",
  },
  {
    title: "Premiere Pro & After Effects",
    description: "Producción de video y efectos visuales de alta calidad para cine y redes sociales.",
    image: "/images/creative-2.jpg",
    fallback: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&q=80",
  },
  {
    title: "Audition & CorelDRAW",
    description: "Edición de audio profesional y diseño gráfico versátil para imprenta y web.",
    image: "/images/creative-3.jpg",
    fallback: "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80",
  },
];

export function CreativeSuite() {
  return (
    <section id="diseno" className="py-24 bg-surface-container/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4 uppercase">
            Suite Creativa y Diseño
          </h2>
          <p className="text-on-surface/60 max-w-2xl mx-auto">
            Instalación garantizada de las herramientas más potentes para creadores de contenido, fotógrafos y diseñadores.
          </p>
          <div className="mt-6 w-24 h-1 bg-primary mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {CREATIVE_APPS.map((item, idx) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass rounded-2xl overflow-hidden group hover:border-primary/50 transition-all duration-500"
            >
              <div className="h-48 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  onError={(e) => {
                    e.currentTarget.src = item.fallback;
                  }}
                />
              </div>
              <div className="p-8">
                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                <p className="text-on-surface/60 line-clamp-3">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
